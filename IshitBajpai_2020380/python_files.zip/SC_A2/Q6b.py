import numpy as np
import scipy as sp
import numpy.linalg as npla
import scipy.linalg as spla

# 6b
for k in range(6,15+1):
    print("k = ",k)
    A = np.array([[1.,1.],[10.**(-k),0.],[0,10.**(-k)]],dtype=float)
    b = np.array([[-10.**(-k)],[1. + 10.**(-k)],[1. - 10.**(-k)]],dtype=float)
    Q,R= np.linalg.qr(A) # R is upper triangular
    Q_inverse = Q.T # since it's Q is othogonal
    x = spla.solve_triangular(R,np.matmul(Q_inverse,b), lower=False) #  Rx=Q^-1b 
    print("x = ",x)
    print("------------------------------")
 
# # 6c
# for k in range(6,15+1):
#     print("k = ",k)
#     A = np.array([[1.,1.],[10.**(-k),0.],[0,10.**(-k)]],dtype=float)
#     b = np.array([[-10.**(-k)],[1. + 10.**(-k)],[1. - 10.**(-k)]],dtype=float)
#     lhs_matrix = np.matmul(A.T,A) #A^T A
#     rhs_matrix = np.matmul(A.T,b) #A^T b
#     try:
#         x = np.linalg.solve(lhs_matrix,rhs_matrix)
#         print("x = ",x)
#     except:
#         print("Singular Matrix!!!")
#     print("------------------------------")
