import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import numpy.linalg as npla
import scipy.linalg as spla
import math


t, y = np.loadtxt("hw2_data_ty.txt").T
# t 1d array of 50 points
A = np.zeros((50,2),dtype=float)
b = np.zeros((50,1),dtype=float)

# setting up matrix A and b
for i in range(50):
    A[i][0] = 1.
    A[i][1] = t[i]
    b[i][0] = np.log(y[i]/(1.-y[i]))

# Sol using Normal Equations
x1 = np.zeros((2,1))  # stores solution of normal equation
lhs_matrix = np.matmul(A.T,A) #A^T A
rhs_matrix = np.matmul(A.T,b) #A^T b
try:
    x = np.linalg.solve(lhs_matrix,rhs_matrix)   # solving for x
    x1 = np.copy(x)
    print("Solution from normal equation")
    print("x = ", x)
except:
        print("Singular Matrix!!!")

print("Euclidean norm of residual = ",npla.norm(np.matmul(A,x1)-b,2))
print("------------------------------")

# Sol using Direct Method
x2 = np.zeros((2,1))  # stores solution of direct method
x,squared_norm,rank,singular_values = npla.lstsq(A,b,rcond=None)
x2 = np.copy(x)
print("Solution from direct equation")
print("x = \n",x2)
print("Euclidean norm of residual calculated from lstsq function = ",math.sqrt(squared_norm[0]))
print("Euclidean norm of residual calculated from norm function  = ",npla.norm(np.matmul(A,x2)-b,2))
print("---------------------------")

print("Euclidean residual is less in case of normal equations by(using norm function) :",npla.norm(np.matmul(A,x2)-b,2) - npla.norm(np.matmul(A,x1)-b,2))






        


plt.figure()
plt.plot(t, y, 'bo', ms=2.5,label = 'Given Data')

# Since both of them are overlapping , I have increased the pointer size for normal equations
# plotting first part
beta_1 = x1[0][0]
alpha_1 = x1[1][0]
plt.plot(t, (1./(1.+ np.exp( (beta_1 + alpha_1 * t)*-1 ))) , 'r+', ms=5,label="Normal equation")

# plotting 2 part
beta_2 = x2[0][0]
alpha_2 = x2[1][0]
plt.plot(t, (1./(1.+ np.exp( (beta_2 + alpha_2 * t)*-1 ))) , 'g+', ms=2.5,label="Direct equation")


plt.grid(True)
plt.xlabel("$t_i$", fontsize=14)
plt.ylabel("$f(t_i)$", fontsize=14)
plt.legend()
plt.gcf().tight_layout()
plt.show()
