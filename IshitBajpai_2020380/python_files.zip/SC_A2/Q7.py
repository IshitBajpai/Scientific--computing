import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import numpy.linalg as npla
import scipy.linalg as spla


x_noisy = np.loadtxt("hw2_data_denoising.txt")
I = np.identity(1000,dtype=float)
D = np.zeros((999,1000),dtype=float)

for i in range(len(D)):
    for j in range(len(D[i])):
        if(i == j):
            D[i][j] = -1
        if(j-i == 1):
            D[i][j] = 1

lamb = [1,100,10000]
col = ["green","blue","red"]
plt.figure()
for i in range(3):
    x_true = npla.solve(I+lamb[i]*np.matmul(D.T,D),x_noisy)
    plt.plot(np.arange(1, 1 + len(x_noisy)),x_true,color=col[i],label = "lambda ="+str(lamb[i]))


# plt.plot(np.arange(1, 1 + len(x_noisy)), x_noisy,
#         color=(0.5, 0.5, 0.5), label="Noisy Signal")

plt.xlabel("$n$", fontsize=14)
plt.ylabel("$x_{noisy}$", fontsize=14)
plt.legend(loc="best")
plt.gcf().tight_layout()
plt.show()