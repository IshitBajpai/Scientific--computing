import numpy as np
import scipy as sp
import numpy.linalg as npla
import scipy.linalg as spla

# 6c
for k in range(6,15+1):
    print("k = ",k)
    A = np.array([[1.,1.],[10.**(-k),0.],[0,10.**(-k)]],dtype=float)
    b = np.array([[-10.**(-k)],[1. + 10.**(-k)],[1. - 10.**(-k)]],dtype=float)
    lhs_matrix = np.matmul(A.T,A) #A^T A
    rhs_matrix = np.matmul(A.T,b) #A^T b
    try:
        x = np.linalg.solve(lhs_matrix,rhs_matrix)
        print("x = ",x)
    except:
        print("Singular Matrix!!!")
    print("------------------------------")